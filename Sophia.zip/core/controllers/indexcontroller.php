<?php 
	//include('html/index/index.php');
	include(DIR_HTML.'/index/index.php');
?>