<?php

/**
* Conexion PHP
*/
class conexion extends mysqli
{
	
	public function __construct()
	{
		parent::__construct(DB_HOST,DB_USER,DB_PASS,DB_NAME);
		$this -> connect_errno ? die ('error en la base de datos') : null;
		$this -> set_charset('utf8');
	}

	public function rows($query){
		return mysqli_num_rows($query);
	}

	public function liberar($query){
		return mysqli_free_result($query);
	}

	public function recorrer($query){
		return fecth_array($query);
	}
}
?>