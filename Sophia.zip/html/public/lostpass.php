 <!-- Modal -->
 						<form role="form">
							<div class="modal fade" id="lostPass" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
							  <div class="modal-dialog" role="document">
							    <div class="modal-content">
							      <div class="modal-header">
							        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="icon icon-times close-modal"></span></button>
							        <h4 class="modal-title" id="myModalLabel">Olvide Clave</h4>
							      </div>
							      <div class="modal-body">
							        <form class="form-horizontal" method="post">
				                        	<div class="form-group">
						                        <label for="name" class="col-sm-2 control-label"><strong>Email:</strong> </label>
						                        <div class="col-sm-10">
						                      		<input type="text" id="emailo" name="emailo" placeholder="Email" autocomplete="off" class="form-control placeholder-no-fix input-form input-form ">
						                    	</div>
				                    		</div>							      
				                    </div>
							      	<div class="modal-footer">
							        <button type="button" class="btn btn-sophia2" data-dismiss="modal">Salir</button>
							        <button type="button" class="btn btn-sophia">Enviar</button>
							      </div>
							    </div>
							  </div>
							</div>
						</form>