function __(id){
	return document.getElementById(id);
}