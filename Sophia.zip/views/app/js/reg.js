function runReg(e){
	var key = e.keyCode;
	if (key == 13) {
		goReg();
	}
}
function goReg(){
	window.alert("se registra bien");
}
							